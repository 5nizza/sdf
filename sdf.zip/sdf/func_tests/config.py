TOOL_EXEC="/home/ayrat/projects/sdf/sub2/binary/sdf-opt"
IIMC_EXEC="/home/ayrat/projects/iimc-2.0/iimc"
