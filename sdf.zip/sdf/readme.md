Standard implementation:
- direct substitution
- variable elimination

After 15 min I fix some of the variable orders,
but if that helps -- is not clear.

The tool adheres to the input/output rules,
but does not output the win region.



Author: ayrat khalimov, TU Graz, ayrat.khalimov at gmail
