#!/bin/bash


SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
BUILD_DIR="$SCRIPT_DIR/syntcomp-build/"

export SDF_TP="$SCRIPT_DIR/third_parties/"

echo "building cudd.."
cd "$SDF_TP/cudd-3.0.0/"
./configure --enable-obj
make -j4

echo "building modified aiger.."
cd "$SDF_TP/aiger-1.9.4/"
./configure
make -j4

echo "building me.."
rm -rf "$BUILD_DIR"
mkdir "$BUILD_DIR"
cd "$BUILD_DIR"

cmake "$SCRIPT_DIR"
make -j4 sdf-opt

cd "$SCRIPT_DIR"

rm -rf binary
mkdir binary
cp "$BUILD_DIR/src/sdf-opt" "$SCRIPT_DIR/binary/sdf-opt"

echo
echo "executable was created in binary/"
echo "run it like: sdf-opt <input_aiger_file>"
